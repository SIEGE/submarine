These small vector graphics Creative Commons 3.0 Unported by Luke (Gaming4JC).
Enjoy!